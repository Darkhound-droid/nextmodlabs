import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const calculatorHistory = pgTable("calculator_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  expression: text("expression").notNull(),
  result: text("result").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const textConversions = pgTable("text_conversions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  originalText: text("original_text").notNull(),
  convertedText: text("converted_text").notNull(),
  conversionType: text("conversion_type").notNull(),
  textStats: jsonb("text_stats"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const imageCompressions = pgTable("image_compressions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  filename: text("filename").notNull(),
  originalSize: integer("original_size").notNull(),
  compressedSize: integer("compressed_size").notNull(),
  compressionRatio: decimal("compression_ratio", { precision: 5, scale: 2 }).notNull(),
  quality: integer("quality").notNull(),
  format: text("format").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const toolUsageStats = pgTable("tool_usage_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  toolName: text("tool_name").notNull(),
  usageCount: integer("usage_count").default(0).notNull(),
  lastUsed: timestamp("last_used").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCalculatorHistorySchema = createInsertSchema(calculatorHistory).pick({
  userId: true,
  expression: true,
  result: true,
});

export const insertTextConversionSchema = createInsertSchema(textConversions).pick({
  userId: true,
  originalText: true,
  convertedText: true,
  conversionType: true,
  textStats: true,
});

export const insertImageCompressionSchema = createInsertSchema(imageCompressions).pick({
  userId: true,
  filename: true,
  originalSize: true,
  compressedSize: true,
  compressionRatio: true,
  quality: true,
  format: true,
});

export const insertToolUsageStatsSchema = createInsertSchema(toolUsageStats).pick({
  toolName: true,
  usageCount: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCalculatorHistory = z.infer<typeof insertCalculatorHistorySchema>;
export type CalculatorHistory = typeof calculatorHistory.$inferSelect;

export type InsertTextConversion = z.infer<typeof insertTextConversionSchema>;
export type TextConversion = typeof textConversions.$inferSelect;

export type InsertImageCompression = z.infer<typeof insertImageCompressionSchema>;
export type ImageCompression = typeof imageCompressions.$inferSelect;

export type InsertToolUsageStats = z.infer<typeof insertToolUsageStatsSchema>;
export type ToolUsageStats = typeof toolUsageStats.$inferSelect;
