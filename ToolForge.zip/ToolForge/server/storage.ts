import { 
  type User, 
  type InsertUser,
  type CalculatorHistory,
  type InsertCalculatorHistory,
  type TextConversion,
  type InsertTextConversion,
  type ImageCompression,
  type InsertImageCompression,
  type ToolUsageStats,
  type InsertToolUsageStats,
  users,
  calculatorHistory,
  textConversions,
  imageCompressions,
  toolUsageStats
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

// Enhanced interface with CRUD methods for all entities
export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Calculator history methods
  getCalculatorHistory(userId?: string, limit?: number): Promise<CalculatorHistory[]>;
  saveCalculation(calculation: InsertCalculatorHistory): Promise<CalculatorHistory>;
  clearCalculatorHistory(userId?: string): Promise<void>;

  // Text conversion methods
  getTextConversions(userId?: string, limit?: number): Promise<TextConversion[]>;
  saveTextConversion(conversion: InsertTextConversion): Promise<TextConversion>;
  clearTextConversions(userId?: string): Promise<void>;

  // Image compression methods
  getImageCompressions(userId?: string, limit?: number): Promise<ImageCompression[]>;
  saveImageCompression(compression: InsertImageCompression): Promise<ImageCompression>;
  clearImageCompressions(userId?: string): Promise<void>;

  // Tool usage stats methods
  getToolUsageStats(): Promise<ToolUsageStats[]>;
  incrementToolUsage(toolName: string): Promise<void>;
  getToolStats(toolName: string): Promise<ToolUsageStats | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Calculator history methods
  async getCalculatorHistory(userId?: string, limit: number = 50): Promise<CalculatorHistory[]> {
    const query = db.select().from(calculatorHistory);
    
    if (userId) {
      return await query
        .where(eq(calculatorHistory.userId, userId))
        .orderBy(desc(calculatorHistory.createdAt))
        .limit(limit);
    } else {
      return await query
        .orderBy(desc(calculatorHistory.createdAt))
        .limit(limit);
    }
  }

  async saveCalculation(calculation: InsertCalculatorHistory): Promise<CalculatorHistory> {
    const [saved] = await db
      .insert(calculatorHistory)
      .values(calculation)
      .returning();
    return saved;
  }

  async clearCalculatorHistory(userId?: string): Promise<void> {
    if (userId) {
      await db.delete(calculatorHistory).where(eq(calculatorHistory.userId, userId));
    } else {
      await db.delete(calculatorHistory);
    }
  }

  // Text conversion methods
  async getTextConversions(userId?: string, limit: number = 50): Promise<TextConversion[]> {
    const query = db.select().from(textConversions);
    
    if (userId) {
      return await query
        .where(eq(textConversions.userId, userId))
        .orderBy(desc(textConversions.createdAt))
        .limit(limit);
    } else {
      return await query
        .orderBy(desc(textConversions.createdAt))
        .limit(limit);
    }
  }

  async saveTextConversion(conversion: InsertTextConversion): Promise<TextConversion> {
    const [saved] = await db
      .insert(textConversions)
      .values(conversion)
      .returning();
    return saved;
  }

  async clearTextConversions(userId?: string): Promise<void> {
    if (userId) {
      await db.delete(textConversions).where(eq(textConversions.userId, userId));
    } else {
      await db.delete(textConversions);
    }
  }

  // Image compression methods
  async getImageCompressions(userId?: string, limit: number = 50): Promise<ImageCompression[]> {
    const query = db.select().from(imageCompressions);
    
    if (userId) {
      return await query
        .where(eq(imageCompressions.userId, userId))
        .orderBy(desc(imageCompressions.createdAt))
        .limit(limit);
    } else {
      return await query
        .orderBy(desc(imageCompressions.createdAt))
        .limit(limit);
    }
  }

  async saveImageCompression(compression: InsertImageCompression): Promise<ImageCompression> {
    const [saved] = await db
      .insert(imageCompressions)
      .values(compression)
      .returning();
    return saved;
  }

  async clearImageCompressions(userId?: string): Promise<void> {
    if (userId) {
      await db.delete(imageCompressions).where(eq(imageCompressions.userId, userId));
    } else {
      await db.delete(imageCompressions);
    }
  }

  // Tool usage stats methods
  async getToolUsageStats(): Promise<ToolUsageStats[]> {
    return await db.select().from(toolUsageStats).orderBy(desc(toolUsageStats.usageCount));
  }

  async incrementToolUsage(toolName: string): Promise<void> {
    // Try to find existing record
    const [existing] = await db
      .select()
      .from(toolUsageStats)
      .where(eq(toolUsageStats.toolName, toolName))
      .limit(1);

    if (existing) {
      // Update existing record
      await db
        .update(toolUsageStats)
        .set({ 
          usageCount: sql`${toolUsageStats.usageCount} + 1`,
          lastUsed: new Date()
        })
        .where(eq(toolUsageStats.toolName, toolName));
    } else {
      // Create new record
      await db.insert(toolUsageStats).values({
        toolName,
        usageCount: 1,
      });
    }
  }

  async getToolStats(toolName: string): Promise<ToolUsageStats | undefined> {
    const [stats] = await db
      .select()
      .from(toolUsageStats)
      .where(eq(toolUsageStats.toolName, toolName));
    return stats || undefined;
  }
}

export const storage = new DatabaseStorage();
