import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCalculatorHistorySchema,
  insertTextConversionSchema,
  insertImageCompressionSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Tool usage tracking
  app.post("/api/tools/:toolName/usage", async (req, res) => {
    try {
      const { toolName } = req.params;
      await storage.incrementToolUsage(toolName);
      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking tool usage:", error);
      res.status(500).json({ error: "Failed to track usage" });
    }
  });

  app.get("/api/tools/stats", async (req, res) => {
    try {
      const stats = await storage.getToolUsageStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching tool stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Calculator history routes
  app.get("/api/calculator/history", async (req, res) => {
    try {
      const { userId, limit } = req.query;
      const history = await storage.getCalculatorHistory(
        userId as string, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(history);
    } catch (error) {
      console.error("Error fetching calculator history:", error);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.post("/api/calculator/history", async (req, res) => {
    try {
      const calculation = insertCalculatorHistorySchema.parse(req.body);
      const saved = await storage.saveCalculation(calculation);
      res.json(saved);
    } catch (error) {
      console.error("Error saving calculation:", error);
      res.status(500).json({ error: "Failed to save calculation" });
    }
  });

  app.delete("/api/calculator/history", async (req, res) => {
    try {
      const { userId } = req.query;
      await storage.clearCalculatorHistory(userId as string);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing calculator history:", error);
      res.status(500).json({ error: "Failed to clear history" });
    }
  });

  // Text conversion routes
  app.get("/api/text-converter/history", async (req, res) => {
    try {
      const { userId, limit } = req.query;
      const history = await storage.getTextConversions(
        userId as string, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(history);
    } catch (error) {
      console.error("Error fetching text conversion history:", error);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.post("/api/text-converter/history", async (req, res) => {
    try {
      const conversion = insertTextConversionSchema.parse(req.body);
      const saved = await storage.saveTextConversion(conversion);
      res.json(saved);
    } catch (error) {
      console.error("Error saving text conversion:", error);
      res.status(500).json({ error: "Failed to save conversion" });
    }
  });

  app.delete("/api/text-converter/history", async (req, res) => {
    try {
      const { userId } = req.query;
      await storage.clearTextConversions(userId as string);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing text conversion history:", error);
      res.status(500).json({ error: "Failed to clear history" });
    }
  });

  // Image compression routes
  app.get("/api/image-compressor/history", async (req, res) => {
    try {
      const { userId, limit } = req.query;
      const history = await storage.getImageCompressions(
        userId as string, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(history);
    } catch (error) {
      console.error("Error fetching image compression history:", error);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.post("/api/image-compressor/history", async (req, res) => {
    try {
      const compression = insertImageCompressionSchema.parse(req.body);
      const saved = await storage.saveImageCompression(compression);
      res.json(saved);
    } catch (error) {
      console.error("Error saving image compression:", error);
      res.status(500).json({ error: "Failed to save compression" });
    }
  });

  app.delete("/api/image-compressor/history", async (req, res) => {
    try {
      const { userId } = req.query;
      await storage.clearImageCompressions(userId as string);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing image compression history:", error);
      res.status(500).json({ error: "Failed to clear history" });
    }
  });

  // Dashboard/analytics route
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const [toolStats, calculatorHistory, textHistory, imageHistory] = await Promise.all([
        storage.getToolUsageStats(),
        storage.getCalculatorHistory(undefined, 10),
        storage.getTextConversions(undefined, 10),
        storage.getImageCompressions(undefined, 10)
      ]);

      res.json({
        toolUsage: toolStats,
        recentActivity: {
          calculations: calculatorHistory,
          textConversions: textHistory,
          imageCompressions: imageHistory
        }
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
