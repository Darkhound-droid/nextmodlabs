import { Link } from "wouter";
import { Wrench } from "lucide-react";
import { Twitter, Github, Linkedin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <Wrench className="h-8 w-8 text-primary mr-3" />
              <h3 className="text-xl font-bold">ToolHub</h3>
            </div>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Professional web tools designed for developers, designers, and professionals. Fast, secure, and always free to use.
            </p>
            <div className="flex space-x-4">
              <Twitter className="h-6 w-6 text-gray-300 hover:text-primary cursor-pointer transition-colors" />
              <Github className="h-6 w-6 text-gray-300 hover:text-primary cursor-pointer transition-colors" />
              <Linkedin className="h-6 w-6 text-gray-300 hover:text-primary cursor-pointer transition-colors" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Tools</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/calculator" className="text-gray-300 hover:text-white transition-colors">
                  Calculator
                </Link>
              </li>
              <li>
                <Link href="/text-converter" className="text-gray-300 hover:text-white transition-colors">
                  Text Converter
                </Link>
              </li>
              <li>
                <Link href="/image-compressor" className="text-gray-300 hover:text-white transition-colors">
                  Image Compressor
                </Link>
              </li>
              <li>
                <Link href="/tools" className="text-gray-300 hover:text-white transition-colors">
                  All Tools
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300">© 2024 ToolHub. All rights reserved. Built with passion for productivity.</p>
        </div>
      </div>
    </footer>
  );
}
