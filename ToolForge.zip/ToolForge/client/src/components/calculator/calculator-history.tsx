import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalculationHistoryEntry } from "@/hooks/use-calculator";

interface CalculatorHistoryProps {
  history: CalculationHistoryEntry[];
  onClearHistory: () => void;
}

export default function CalculatorHistory({ history, onClearHistory }: CalculatorHistoryProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-secondary">Calculation History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {history.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-8">No calculations yet</p>
          ) : (
            history.map((entry, index) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-600 break-all">{entry.expression}</div>
                <div className="text-lg font-semibold text-secondary">= {entry.result}</div>
              </div>
            ))
          )}
        </div>
        {history.length > 0 && (
          <Button
            onClick={onClearHistory}
            variant="ghost"
            className="w-full mt-4 text-red-500 hover:text-red-600 text-sm font-medium"
          >
            Clear History
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
