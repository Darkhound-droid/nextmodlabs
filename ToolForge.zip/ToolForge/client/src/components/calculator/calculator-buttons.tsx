import { Button } from "@/components/ui/button";

interface CalculatorButtonsProps {
  onNumber: (num: string) => void;
  onDecimal: () => void;
  onClear: () => void;
  onClearEntry: () => void;
  onBackspace: () => void;
  onOperation: (op: string) => void;
  onEquals: () => void;
  onScientific: (op: string) => void;
}

export default function CalculatorButtons({
  onNumber,
  onDecimal,
  onClear,
  onClearEntry,
  onBackspace,
  onOperation,
  onEquals,
  onScientific
}: CalculatorButtonsProps) {
  return (
    <div>
      {/* Main Calculator Buttons */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {/* Row 1 */}
        <Button
          onClick={onClear}
          className="bg-red-500 hover:bg-red-600 text-white font-semibold py-4 h-12"
        >
          C
        </Button>
        <Button
          onClick={onClearEntry}
          className="bg-amber-500 hover:bg-amber-600 text-white font-semibold py-4 h-12"
        >
          CE
        </Button>
        <Button
          onClick={onBackspace}
          className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-4 h-12"
        >
          ⌫
        </Button>
        <Button
          onClick={() => onOperation("divide")}
          className="bg-primary hover:bg-blue-600 text-white font-semibold py-4 h-12"
        >
          ÷
        </Button>

        {/* Row 2 */}
        <Button
          onClick={() => onNumber("7")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          7
        </Button>
        <Button
          onClick={() => onNumber("8")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          8
        </Button>
        <Button
          onClick={() => onNumber("9")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          9
        </Button>
        <Button
          onClick={() => onOperation("multiply")}
          className="bg-primary hover:bg-blue-600 text-white font-semibold py-4 h-12"
        >
          ×
        </Button>

        {/* Row 3 */}
        <Button
          onClick={() => onNumber("4")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          4
        </Button>
        <Button
          onClick={() => onNumber("5")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          5
        </Button>
        <Button
          onClick={() => onNumber("6")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          6
        </Button>
        <Button
          onClick={() => onOperation("subtract")}
          className="bg-primary hover:bg-blue-600 text-white font-semibold py-4 h-12"
        >
          −
        </Button>

        {/* Row 4 */}
        <Button
          onClick={() => onNumber("1")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          1
        </Button>
        <Button
          onClick={() => onNumber("2")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          2
        </Button>
        <Button
          onClick={() => onNumber("3")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          3
        </Button>
        <Button
          onClick={() => onOperation("add")}
          className="bg-primary hover:bg-blue-600 text-white font-semibold py-4 h-12"
        >
          +
        </Button>

        {/* Row 5 */}
        <Button
          onClick={() => onNumber("0")}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12 col-span-2"
        >
          0
        </Button>
        <Button
          onClick={onDecimal}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-4 h-12"
        >
          .
        </Button>
        <Button
          onClick={onEquals}
          className="bg-accent hover:bg-emerald-600 text-white font-semibold py-4 h-12"
        >
          =
        </Button>
      </div>

      {/* Scientific Functions */}
      <div className="pt-6 border-t border-gray-200">
        <h3 className="text-sm font-semibold text-gray-600 mb-3">Scientific Functions</h3>
        <div className="grid grid-cols-4 gap-2">
          <Button
            onClick={() => onScientific("sqrt")}
            className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-medium py-2 px-3 text-sm"
            variant="secondary"
          >
            √
          </Button>
          <Button
            onClick={() => onScientific("power")}
            className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-medium py-2 px-3 text-sm"
            variant="secondary"
          >
            x²
          </Button>
          <Button
            onClick={() => onScientific("sin")}
            className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-medium py-2 px-3 text-sm"
            variant="secondary"
          >
            sin
          </Button>
          <Button
            onClick={() => onScientific("cos")}
            className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-medium py-2 px-3 text-sm"
            variant="secondary"
          >
            cos
          </Button>
        </div>
      </div>
    </div>
  );
}
