interface CalculatorDisplayProps {
  display: string;
  expression: string;
}

export default function CalculatorDisplay({ display, expression }: CalculatorDisplayProps) {
  return (
    <div className="mb-6">
      <div className="bg-gray-900 rounded-lg p-4 mb-2">
        <div className="text-right text-gray-400 text-sm mb-1 min-h-[20px]">
          {expression}
        </div>
        <div className="text-right text-white text-3xl font-mono min-h-[48px] break-all">
          {display}
        </div>
      </div>
    </div>
  );
}
