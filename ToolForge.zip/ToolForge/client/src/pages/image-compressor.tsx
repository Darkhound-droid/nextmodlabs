import { useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { useImageCompressor } from "@/hooks/use-image-compressor";
import { useToast } from "@/hooks/use-toast";
import { 
  CloudUpload, 
  Download, 
  RotateCcw, 
  ImageDown,
  FileImage,
  Zap
} from "lucide-react";

export default function ImageCompressor() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const {
    images,
    quality,
    format,
    isProcessing,
    setQuality,
    setFormat,
    processFiles,
    downloadImage,
    downloadAll,
    reset,
    formatBytes,
    getQualityLabel,
  } = useImageCompressor();

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFiles(files);
      toast({
        title: "Processing images",
        description: `Compressing ${files.length} image${files.length > 1 ? 's' : ''}...`,
      });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(files);
      toast({
        title: "Processing images",
        description: `Compressing ${files.length} image${files.length > 1 ? 's' : ''}...`,
      });
    }
  };

  const totalSavings = images.reduce((acc, img) => acc + (img.originalSize - img.compressedSize), 0);
  const averageCompression = images.length > 0 
    ? Math.round(images.reduce((acc, img) => acc + img.compressionRatio, 0) / images.length)
    : 0;

  return (
    <section className="py-16 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-secondary mb-4">Image Compressor</h1>
          <p className="text-lg text-gray-600">Reduce image file sizes while maintaining quality</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-secondary">Upload Images</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Upload Area */}
              <div
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={handleFileSelect}
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer group"
              >
                <CloudUpload className="h-12 w-12 text-gray-400 mx-auto mb-4 group-hover:text-primary transition-colors" />
                <h4 className="text-lg font-medium text-gray-700 mb-2">Drop images here or click to browse</h4>
                <p className="text-gray-500 mb-4">Supports JPEG, PNG, WebP files up to 10MB each</p>
                <Button className="bg-primary hover:bg-blue-600">
                  Choose Files
                </Button>
              </div>

              <Input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />

              {/* Compression Settings */}
              <div className="mt-6 space-y-4">
                <h4 className="font-semibold text-secondary">Compression Settings</h4>
                
                {/* Quality Slider */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Quality Level: {getQualityLabel(quality)} ({quality}%)
                  </Label>
                  <Input
                    type="range"
                    min="10"
                    max="100"
                    value={quality}
                    onChange={(e) => setQuality(Number(e.target.value))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500 mt-1">
                    <span>Low (10%)</span>
                    <span>Max (100%)</span>
                  </div>
                </div>

                {/* Output Format */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">Output Format</Label>
                  <Select value={format} onValueChange={(value: "jpeg" | "png" | "webp") => setFormat(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="jpeg">JPEG (Smaller file size)</SelectItem>
                      <SelectItem value="png">PNG (Better quality)</SelectItem>
                      <SelectItem value="webp">WebP (Best compression)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Options */}
                <div className="flex items-center space-x-2">
                  <Checkbox id="maintain-aspect" defaultChecked />
                  <Label htmlFor="maintain-aspect" className="text-sm text-gray-700">
                    Maintain aspect ratio
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results Section */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-secondary">Results</CardTitle>
            </CardHeader>
            <CardContent>
              {isProcessing && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-lg font-medium text-secondary">Processing images...</p>
                  <Progress value={65} className="mt-4" />
                </div>
              )}

              {!isProcessing && images.length === 0 && (
                <div className="text-center py-12">
                  <ImageDown className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Upload images to see compression results</p>
                </div>
              )}

              {!isProcessing && images.length > 0 && (
                <div>
                  {/* Summary Stats */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <div className="text-xl font-bold text-red-600">{formatBytes(images.reduce((acc, img) => acc + img.originalSize, 0))}</div>
                      <div className="text-sm text-gray-600">Original Size</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-xl font-bold text-green-600">{formatBytes(images.reduce((acc, img) => acc + img.compressedSize, 0))}</div>
                      <div className="text-sm text-gray-600">Compressed Size</div>
                    </div>
                  </div>

                  <div className="text-center p-4 bg-accent/10 rounded-lg mb-6">
                    <div className="text-2xl font-bold text-accent">{averageCompression}% Average Reduction</div>
                    <div className="text-sm text-gray-600">{formatBytes(totalSavings)} Space Saved</div>
                  </div>

                  {/* Image List */}
                  <div className="space-y-4 max-h-64 overflow-y-auto mb-6">
                    {images.map((image, index) => (
                      <div key={index} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                        <img 
                          src={image.preview} 
                          alt="Preview" 
                          className="w-12 h-12 object-cover rounded"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {image.originalFile.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {formatBytes(image.originalSize)} → {formatBytes(image.compressedSize)} 
                            <span className="text-green-600 ml-1">(-{image.compressionRatio}%)</span>
                          </p>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => downloadImage(image)}
                          className="bg-primary hover:bg-blue-600"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button 
                      onClick={downloadAll} 
                      className="w-full bg-accent hover:bg-emerald-600"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download All ({images.length} images)
                    </Button>
                    <Button 
                      onClick={reset} 
                      variant="outline" 
                      className="w-full"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Start Over
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
