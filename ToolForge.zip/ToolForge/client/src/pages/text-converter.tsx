import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useTextConverter } from "@/hooks/use-text-converter";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowUp, 
  ArrowDown, 
  Type, 
  RotateCcw, 
  Minus, 
  Copy, 
  Trash2,
  Clock,
  Hash,
  FileText,
  AlignLeft
} from "lucide-react";

const conversionOptions = [
  { id: "uppercase", label: "UPPERCASE", icon: ArrowUp, color: "bg-primary hover:bg-blue-600" },
  { id: "lowercase", label: "lowercase", icon: ArrowDown, color: "bg-accent hover:bg-emerald-600" },
  { id: "title-case", label: "Title Case", icon: Type, color: "bg-purple-500 hover:bg-purple-600" },
  { id: "sentence-case", label: "Sentence case", icon: FileText, color: "bg-indigo-500 hover:bg-indigo-600" },
  { id: "reverse", label: "Reverse", icon: RotateCcw, color: "bg-amber-500 hover:bg-amber-600" },
  { id: "remove-spaces", label: "Remove Spaces", icon: Minus, color: "bg-red-500 hover:bg-red-600" },
  { id: "remove-extra-spaces", label: "Remove Extra Spaces", icon: AlignLeft, color: "bg-teal-500 hover:bg-teal-600" },
  { id: "capitalize-words", label: "Capitalize Words", icon: Hash, color: "bg-pink-500 hover:bg-pink-600" },
];

export default function TextConverter() {
  const { input, output, stats, setInput, convert, copyToClipboard, clearAll } = useTextConverter();
  const { toast } = useToast();
  const [copySuccess, setCopySuccess] = useState(false);

  const handleCopy = async () => {
    const success = await copyToClipboard();
    if (success) {
      setCopySuccess(true);
      toast({
        title: "Copied!",
        description: "Text copied to clipboard successfully.",
      });
      setTimeout(() => setCopySuccess(false), 2000);
    } else {
      toast({
        title: "Copy failed",
        description: "Failed to copy text to clipboard.",
        variant: "destructive",
      });
    }
  };

  return (
    <section className="py-16 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-secondary mb-4">Text Converter & Analyzer</h1>
          <p className="text-lg text-gray-600">Transform and analyze your text with powerful tools</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-secondary">Input Text</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="h-64 resize-none"
                placeholder="Enter your text here to convert and analyze..."
              />

              {/* Text Stats */}
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">{stats.characters}</div>
                  <div className="text-sm text-gray-600">Characters</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-accent">{stats.words}</div>
                  <div className="text-sm text-gray-600">Words</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{stats.lines}</div>
                  <div className="text-sm text-gray-600">Lines</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-amber-600">{stats.paragraphs}</div>
                  <div className="text-sm text-gray-600">Paragraphs</div>
                </div>
              </div>

              {/* Conversion Buttons */}
              <div className="mt-6 grid grid-cols-2 gap-3">
                {conversionOptions.map((option) => {
                  const IconComponent = option.icon;
                  return (
                    <Button
                      key={option.id}
                      onClick={() => convert(option.id)}
                      className={`${option.color} text-white font-medium py-3 px-4 transition-colors`}
                    >
                      <IconComponent className="h-4 w-4 mr-2" />
                      {option.label}
                    </Button>
                  );
                })}
              </div>

              <div className="mt-4 flex gap-2">
                <Button onClick={clearAll} variant="outline" className="flex-1">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear All
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Output Section */}
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl font-semibold text-secondary">Converted Text</CardTitle>
                <Button
                  onClick={handleCopy}
                  variant="outline"
                  className={copySuccess ? "bg-green-50 text-green-600 border-green-200" : ""}
                  disabled={!output}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  {copySuccess ? "Copied!" : "Copy"}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                value={output}
                readOnly
                className="h-64 resize-none bg-gray-50"
                placeholder="Converted text will appear here..."
              />

              {/* Additional Analysis */}
              <div className="mt-6">
                <h4 className="font-semibold text-secondary mb-3">Text Analysis</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-gray-600">Reading Time (avg)</span>
                    </div>
                    <Badge variant="secondary">
                      {stats.readingTime} min{stats.readingTime !== 1 ? 's' : ''}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-gray-600">Sentences</span>
                    </div>
                    <Badge variant="secondary">{stats.sentences}</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Hash className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-gray-600">Average Word Length</span>
                    </div>
                    <Badge variant="secondary">{stats.averageWordLength} chars</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
