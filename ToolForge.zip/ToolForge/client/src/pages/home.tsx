import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Zap, Shield, Smartphone, Calculator, Type, ImageDown } from "lucide-react";

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="gradient-bg py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-secondary mb-6">
              Professional Web Tools{" "}
              <span className="text-primary">Made Simple</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Access powerful, professional-grade tools right in your browser. No downloads, no installations—just instant productivity for developers, designers, and professionals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/tools">
                <Button size="lg" className="bg-primary hover:bg-blue-600 text-white px-8 py-4 text-lg font-semibold shadow-lg transform hover:scale-105 transition-all duration-200">
                  Explore Tools <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">Why Choose ToolHub?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">Built for professionals who need reliable, fast, and secure tools</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-all duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Lightning Fast</h3>
                <p className="text-gray-600">Optimized for speed with instant results and minimal loading times</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-all duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Secure & Private</h3>
                <p className="text-gray-600">All processing happens locally in your browser. Your data never leaves your device</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-all duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Mobile Ready</h3>
                <p className="text-gray-600">Responsive design that works perfectly on all devices and screen sizes</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Tools Preview */}
      <section className="py-20 gradient-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">Featured Tools</h2>
            <p className="text-lg text-gray-600">Essential utilities for everyday productivity</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-xl transition-shadow duration-300 border border-gray-100">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Calculator className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Advanced Calculator</h3>
                <p className="text-gray-600 mb-4">Full-featured calculator with scientific functions and history</p>
                <Link href="/calculator" className="text-primary font-medium hover:text-blue-600 inline-flex items-center">
                  Try it now <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow duration-300 border border-gray-100">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Type className="h-6 w-6 text-accent" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Text Converter</h3>
                <p className="text-gray-600 mb-4">Transform text with case conversion, word count, and formatting tools</p>
                <Link href="/text-converter" className="text-primary font-medium hover:text-blue-600 inline-flex items-center">
                  Try it now <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow duration-300 border border-gray-100">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <ImageDown className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-3">Image Compressor</h3>
                <p className="text-gray-600 mb-4">Reduce image file sizes while maintaining quality</p>
                <Link href="/image-compressor" className="text-primary font-medium hover:text-blue-600 inline-flex items-center">
                  Try it now <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
