import { Card, CardContent } from "@/components/ui/card";
import { useCalculator } from "@/hooks/use-calculator";
import CalculatorDisplay from "@/components/calculator/calculator-display";
import CalculatorButtons from "@/components/calculator/calculator-buttons";
import CalculatorHistory from "@/components/calculator/calculator-history";

export default function Calculator() {
  const calculator = useCalculator();

  return (
    <section className="py-16 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-secondary mb-4">Advanced Calculator</h1>
          <p className="text-lg text-gray-600">Professional calculator with scientific functions</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calculator Interface */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <CalculatorDisplay 
                  display={calculator.display}
                  expression={calculator.expression}
                />
                <CalculatorButtons
                  onNumber={calculator.inputNumber}
                  onDecimal={calculator.inputDecimal}
                  onClear={calculator.clear}
                  onClearEntry={calculator.clearEntry}
                  onBackspace={calculator.backspace}
                  onOperation={calculator.performOperation}
                  onEquals={calculator.equals}
                  onScientific={calculator.scientificOperation}
                />
              </CardContent>
            </Card>
          </div>

          {/* History Panel */}
          <div className="lg:col-span-1">
            <CalculatorHistory
              history={calculator.history}
              onClearHistory={calculator.clearHistory}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
