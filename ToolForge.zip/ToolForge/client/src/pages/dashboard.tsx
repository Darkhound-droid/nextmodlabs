import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToolAnalytics } from "@/hooks/use-tool-analytics";
import { BarChart3, TrendingUp, Activity, Clock, Calculator, Type, ImageDown } from "lucide-react";

export default function Dashboard() {
  const { dashboardStats, isDashboardLoading, dashboardError } = useToolAnalytics();

  if (isDashboardLoading) {
    return (
      <section className="py-16 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </section>
    );
  }

  if (dashboardError) {
    return (
      <section className="py-16 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-red-600">Error loading dashboard data</p>
          </div>
        </div>
      </section>
    );
  }

  const totalUsage = dashboardStats?.toolUsage?.reduce((sum: number, tool: any) => sum + tool.usageCount, 0) || 0;
  const mostUsedTool = dashboardStats?.toolUsage?.[0];

  const getToolIcon = (toolName: string) => {
    switch (toolName.toLowerCase()) {
      case 'calculator':
        return <Calculator className="h-5 w-5 text-primary" />;
      case 'text-converter':
        return <Type className="h-5 w-5 text-accent" />;
      case 'image-compressor':
        return <ImageDown className="h-5 w-5 text-purple-600" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <section className="py-16 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-secondary mb-4">Analytics Dashboard</h1>
          <p className="text-lg text-gray-600">Tool usage statistics and recent activity</p>
        </div>

        {/* Overview Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Usage</p>
                  <p className="text-2xl font-bold text-secondary">{totalUsage.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-accent/10 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-accent" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Tools</p>
                  <p className="text-2xl font-bold text-secondary">{dashboardStats?.toolUsage?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Activity className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Most Popular</p>
                  <p className="text-lg font-bold text-secondary capitalize">{mostUsedTool?.toolName || 'N/A'}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Clock className="h-6 w-6 text-amber-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Data Available</p>
                  <p className="text-sm font-bold text-secondary">
                    {dashboardStats ? 'Yes' : 'Loading...'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Tool Usage Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-secondary">Tool Usage Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dashboardStats?.toolUsage?.map((tool: any) => (
                  <div key={tool.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      {getToolIcon(tool.toolName)}
                      <div className="ml-3">
                        <p className="font-medium text-secondary capitalize">{tool.toolName.replace('-', ' ')}</p>
                        <p className="text-sm text-gray-600">
                          Created: {new Date(tool.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{tool.usageCount}</p>
                      <p className="text-sm text-gray-600">uses</p>
                    </div>
                  </div>
                ))}
                {(!dashboardStats?.toolUsage || dashboardStats.toolUsage.length === 0) && (
                  <div className="text-center py-8">
                    <Activity className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No tool usage data yet</p>
                    <p className="text-sm text-gray-400">Start using the tools to see statistics here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-secondary">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Calculator History */}
                {dashboardStats?.recentActivity?.calculations && dashboardStats.recentActivity.calculations.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                      <Calculator className="h-4 w-4 text-primary mr-2" />
                      Recent Calculations
                    </h4>
                    <div className="space-y-2">
                      {dashboardStats.recentActivity.calculations.slice(0, 3).map((calc: any) => (
                        <div key={calc.id} className="p-3 bg-primary/5 rounded-lg">
                          <p className="text-sm font-medium text-gray-800">{calc.expression} = {calc.result}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(calc.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Text Conversions */}
                {dashboardStats?.recentActivity?.textConversions && dashboardStats.recentActivity.textConversions.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                      <Type className="h-4 w-4 text-accent mr-2" />
                      Recent Text Conversions
                    </h4>
                    <div className="space-y-2">
                      {dashboardStats.recentActivity.textConversions.slice(0, 3).map((conv: any) => (
                        <div key={conv.id} className="p-3 bg-accent/5 rounded-lg">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs capitalize">
                              {conv.conversionType.replace('-', ' ')}
                            </Badge>
                            <p className="text-xs text-gray-500">
                              {new Date(conv.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Image Compressions */}
                {dashboardStats?.recentActivity?.imageCompressions && dashboardStats.recentActivity.imageCompressions.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                      <ImageDown className="h-4 w-4 text-purple-600 mr-2" />
                      Recent Image Compressions
                    </h4>
                    <div className="space-y-2">
                      {dashboardStats.recentActivity.imageCompressions.slice(0, 3).map((img: any) => (
                        <div key={img.id} className="p-3 bg-purple-50 rounded-lg">
                          <p className="text-sm font-medium text-gray-800">{img.filename}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {img.compressionRatio}% reduction
                            </Badge>
                            <p className="text-xs text-gray-500">
                              {new Date(img.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Empty State */}
                {(!dashboardStats?.recentActivity?.calculations?.length && 
                  !dashboardStats?.recentActivity?.textConversions?.length && 
                  !dashboardStats?.recentActivity?.imageCompressions?.length) && (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No recent activity</p>
                    <p className="text-sm text-gray-400">Activity will appear here as you use the tools</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}