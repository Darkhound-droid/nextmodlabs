import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calculator, Type, ImageDown, ArrowRight } from "lucide-react";

const tools = [
  {
    id: "calculator",
    name: "Advanced Calculator",
    description: "Professional calculator with scientific functions, memory operations, and calculation history. Perfect for complex mathematical operations.",
    icon: Calculator,
    iconBg: "bg-primary/10",
    iconColor: "text-primary",
    href: "/calculator",
    tags: ["Scientific", "Memory", "History"]
  },
  {
    id: "text-converter",
    name: "Text Converter",
    description: "Transform text with case conversion, reverse text, word counting, and character analysis. Essential for content creators and developers.",
    icon: Type,
    iconBg: "bg-accent/10",
    iconColor: "text-accent",
    href: "/text-converter",
    tags: ["Case Convert", "Word Count", "Reverse"]
  },
  {
    id: "image-compressor",
    name: "Image Compressor",
    description: "Reduce image file sizes while maintaining visual quality. Supports JPEG, PNG, and WebP formats with adjustable compression levels.",
    icon: ImageDown,
    iconBg: "bg-purple-100",
    iconColor: "text-purple-600",
    href: "/image-compressor",
    tags: ["JPEG/PNG", "Quality Control", "Batch Process"]
  }
];

export default function Tools() {
  return (
    <section className="py-16 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-secondary mb-4">All Tools</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Choose from our collection of professional-grade web tools</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tools.map((tool) => {
            const IconComponent = tool.icon;
            return (
              <Link key={tool.id} href={tool.href}>
                <Card className="hover:shadow-xl transition-all duration-300 p-8 border border-gray-100 group cursor-pointer h-full">
                  <CardContent className="p-0">
                    <div className={`w-16 h-16 ${tool.iconBg} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                      <IconComponent className={`h-8 w-8 ${tool.iconColor}`} />
                    </div>
                    <h3 className="text-2xl font-semibold text-secondary mb-4">{tool.name}</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">{tool.description}</p>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {tool.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className={`${tool.iconBg} ${tool.iconColor} border-0`}>
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center text-primary font-medium group-hover:text-blue-600">
                      Open Tool <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
