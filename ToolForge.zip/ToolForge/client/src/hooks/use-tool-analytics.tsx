import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export interface ToolUsageStats {
  id: string;
  toolName: string;
  usageCount: number;
  lastUsed: string;
  createdAt: string;
}

export interface DashboardStats {
  toolUsage: ToolUsageStats[];
  recentActivity: {
    calculations: any[];
    textConversions: any[];
    imageCompressions: any[];
  };
}

export function useToolAnalytics() {
  const queryClient = useQueryClient();

  // Get dashboard stats
  const dashboardQuery = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: async (): Promise<DashboardStats> => {
      const response = await fetch("/api/dashboard/stats");
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard stats");
      }
      return response.json();
    },
  });

  // Get tool usage stats
  const toolStatsQuery = useQuery({
    queryKey: ["/api/tools/stats"],
    queryFn: async (): Promise<ToolUsageStats[]> => {
      const response = await fetch("/api/tools/stats");
      if (!response.ok) {
        throw new Error("Failed to fetch tool stats");
      }
      return response.json();
    },
  });

  // Track tool usage
  const trackUsageMutation = useMutation({
    mutationFn: async (toolName: string) => {
      const response = await fetch(`/api/tools/${toolName}/usage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        throw new Error("Failed to track usage");
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch tool stats
      queryClient.invalidateQueries({ queryKey: ["/api/tools/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
  });

  return {
    dashboardStats: dashboardQuery.data,
    toolStats: toolStatsQuery.data,
    isDashboardLoading: dashboardQuery.isLoading,
    isToolStatsLoading: toolStatsQuery.isLoading,
    dashboardError: dashboardQuery.error,
    toolStatsError: toolStatsQuery.error,
    trackUsage: trackUsageMutation.mutate,
    isTrackingUsage: trackUsageMutation.isPending,
  };
}