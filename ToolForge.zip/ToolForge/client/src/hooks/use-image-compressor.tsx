import { useState, useCallback } from "react";

export interface CompressedImage {
  originalFile: File;
  compressedFile: File;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  preview: string;
}

export function useImageCompressor() {
  const [images, setImages] = useState<CompressedImage[]>([]);
  const [quality, setQuality] = useState(80);
  const [format, setFormat] = useState<"jpeg" | "png" | "webp">("jpeg");
  const [isProcessing, setIsProcessing] = useState(false);

  const compressImage = useCallback(async (file: File): Promise<CompressedImage | null> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        // Set canvas dimensions
        canvas.width = img.width;
        canvas.height = img.height;

        if (!ctx) {
          resolve(null);
          return;
        }

        // Draw image on canvas
        ctx.drawImage(img, 0, 0);

        // Convert to desired format and quality
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              resolve(null);
              return;
            }

            const compressedFile = new File([blob], `compressed_${file.name}`, {
              type: `image/${format}`,
              lastModified: Date.now(),
            });

            const compressionRatio = Math.round(
              ((file.size - compressedFile.size) / file.size) * 100
            );

            resolve({
              originalFile: file,
              compressedFile,
              originalSize: file.size,
              compressedSize: compressedFile.size,
              compressionRatio,
              preview: canvas.toDataURL(),
            });
          },
          `image/${format}`,
          quality / 100
        );
      };

      img.src = URL.createObjectURL(file);
    });
  }, [quality, format]);

  const processFiles = useCallback(async (files: FileList) => {
    setIsProcessing(true);
    const compressedImages: CompressedImage[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        const compressed = await compressImage(file);
        if (compressed) {
          compressedImages.push(compressed);
        }
      }
    }

    setImages(compressedImages);
    setIsProcessing(false);
  }, [compressImage]);

  const downloadImage = useCallback((image: CompressedImage) => {
    const url = URL.createObjectURL(image.compressedFile);
    const a = document.createElement('a');
    a.href = url;
    a.download = image.compressedFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, []);

  const downloadAll = useCallback(() => {
    images.forEach(downloadImage);
  }, [images, downloadImage]);

  const reset = useCallback(() => {
    setImages([]);
  }, []);

  const formatBytes = useCallback((bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }, []);

  const getQualityLabel = useCallback((value: number): string => {
    if (value >= 90) return 'Maximum';
    if (value >= 70) return 'High';
    if (value >= 40) return 'Medium';
    return 'Low';
  }, []);

  return {
    images,
    quality,
    format,
    isProcessing,
    setQuality,
    setFormat,
    processFiles,
    downloadImage,
    downloadAll,
    reset,
    formatBytes,
    getQualityLabel,
  };
}
