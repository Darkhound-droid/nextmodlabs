import { useState, useCallback } from "react";

export interface CalculationHistoryEntry {
  expression: string;
  result: string;
  timestamp: Date;
}

export function useCalculator() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [history, setHistory] = useState<CalculationHistoryEntry[]>([]);
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputNumber = useCallback((num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  }, [display, waitingForOperand]);

  const inputDecimal = useCallback(() => {
    if (waitingForOperand) {
      setDisplay("0.");
      setWaitingForOperand(false);
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".");
    }
  }, [display, waitingForOperand]);

  const clear = useCallback(() => {
    setDisplay("0");
    setExpression("");
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  }, []);

  const clearEntry = useCallback(() => {
    setDisplay("0");
  }, []);

  const backspace = useCallback(() => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
    }
  }, [display]);

  const performOperation = useCallback((nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);

      setDisplay(`${newValue}`);
      setPreviousValue(newValue);
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
    setExpression(`${previousValue === null ? inputValue : previousValue} ${getOperatorSymbol(nextOperation)} `);
  }, [display, previousValue, operation]);

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case "add":
        return firstValue + secondValue;
      case "subtract":
        return firstValue - secondValue;
      case "multiply":
        return firstValue * secondValue;
      case "divide":
        return firstValue / secondValue;
      case "equals":
        return secondValue;
      default:
        return secondValue;
    }
  };

  const getOperatorSymbol = (op: string): string => {
    switch (op) {
      case "add": return "+";
      case "subtract": return "−";
      case "multiply": return "×";
      case "divide": return "÷";
      default: return "";
    }
  };

  const equals = useCallback(() => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation);
      const fullExpression = `${expression}${display}`;
      
      setDisplay(`${newValue}`);
      setExpression("");
      setPreviousValue(null);
      setOperation(null);
      setWaitingForOperand(true);

      // Add to history
      const historyEntry: CalculationHistoryEntry = {
        expression: fullExpression,
        result: `${newValue}`,
        timestamp: new Date()
      };
      setHistory(prev => [historyEntry, ...prev.slice(0, 9)]);
    }
  }, [display, expression, previousValue, operation]);

  const scientificOperation = useCallback((op: string) => {
    const inputValue = parseFloat(display);
    let result: number;

    switch (op) {
      case "sqrt":
        result = Math.sqrt(inputValue);
        break;
      case "power":
        result = Math.pow(inputValue, 2);
        break;
      case "sin":
        result = Math.sin(inputValue * Math.PI / 180);
        break;
      case "cos":
        result = Math.cos(inputValue * Math.PI / 180);
        break;
      default:
        return;
    }

    const fullExpression = `${op}(${inputValue})`;
    setDisplay(`${result}`);
    setExpression("");
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(true);

    // Add to history
    const historyEntry: CalculationHistoryEntry = {
      expression: fullExpression,
      result: `${result}`,
      timestamp: new Date()
    };
    setHistory(prev => [historyEntry, ...prev.slice(0, 9)]);
  }, [display]);

  const clearHistory = useCallback(() => {
    setHistory([]);
  }, []);

  return {
    display,
    expression,
    history,
    inputNumber,
    inputDecimal,
    clear,
    clearEntry,
    backspace,
    performOperation,
    equals,
    scientificOperation,
    clearHistory
  };
}
