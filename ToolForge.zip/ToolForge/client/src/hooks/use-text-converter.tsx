import { useState, useCallback, useMemo } from "react";

export interface TextStats {
  characters: number;
  words: number;
  lines: number;
  paragraphs: number;
  sentences: number;
  averageWordLength: number;
  readingTime: number;
}

export function useTextConverter() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");

  const stats: TextStats = useMemo(() => {
    const text = input.trim();
    const characters = input.length;
    const words = text ? text.split(/\s+/).length : 0;
    const lines = input ? input.split('\n').length : 0;
    const paragraphs = text ? text.split(/\n\s*\n/).length : 0;
    const sentences = text ? (text.match(/[.!?]+/g) || []).length : 0;
    const averageWordLength = words > 0 ? text.replace(/\s+/g, '').length / words : 0;
    const readingTime = Math.ceil(words / 200); // Average reading speed of 200 words per minute

    return {
      characters,
      words,
      lines,
      paragraphs,
      sentences,
      averageWordLength: Math.round(averageWordLength * 10) / 10,
      readingTime
    };
  }, [input]);

  const convert = useCallback((type: string) => {
    let result = input;

    switch (type) {
      case "uppercase":
        result = input.toUpperCase();
        break;
      case "lowercase":
        result = input.toLowerCase();
        break;
      case "title-case":
        result = input.replace(/\b\w/g, char => char.toUpperCase());
        break;
      case "sentence-case":
        result = input.charAt(0).toUpperCase() + input.slice(1).toLowerCase();
        break;
      case "reverse":
        result = input.split('').reverse().join('');
        break;
      case "remove-spaces":
        result = input.replace(/\s+/g, '');
        break;
      case "remove-duplicates":
        const lines = input.split('\n');
        result = Array.from(new Set(lines)).join('\n');
        break;
      case "remove-extra-spaces":
        result = input.replace(/\s+/g, ' ').trim();
        break;
      case "capitalize-words":
        result = input.replace(/\b\w+/g, word => 
          word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        );
        break;
      default:
        result = input;
    }

    setOutput(result);
  }, [input]);

  const copyToClipboard = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(output);
      return true;
    } catch (err) {
      console.error('Failed to copy text: ', err);
      return false;
    }
  }, [output]);

  const clearAll = useCallback(() => {
    setInput("");
    setOutput("");
  }, []);

  return {
    input,
    output,
    stats,
    setInput,
    convert,
    copyToClipboard,
    clearAll
  };
}
